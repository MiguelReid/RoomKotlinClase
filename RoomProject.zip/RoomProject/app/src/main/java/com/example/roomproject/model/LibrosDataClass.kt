package com.example.roomproject.model

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.android.parcel.Parcelize


@Parcelize
@Entity(tableName = "Libros")
data class LibrosDataClass(
    @PrimaryKey(autoGenerate = true)
    var ID: Int? ,
    @ColumnInfo(name = "titulo")
    var titulo : String,
    @ColumnInfo(name = "autor")
    var autor: String
    ): Parcelable
