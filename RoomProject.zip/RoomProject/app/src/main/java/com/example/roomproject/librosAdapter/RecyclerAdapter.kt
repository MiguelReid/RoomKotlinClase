package com.example.roomproject.librosAdapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.roomproject.R
import com.example.roomproject.databinding.ListaLibrosBinding
import com.example.roomproject.model.LibrosDataClass
import com.example.roomproject.view.AddActivity
import com.example.roomproject.viewModel.MainViewModel


class RecyclerAdapter : RecyclerView.Adapter<RecyclerAdapter.LibroHolder>(){
    lateinit var context: Context
    private var lista = emptyList<LibrosDataClass>()
    private lateinit var viewModel: MainViewModel
    //private var oldData = emptyList<LibrosDataClass>()//datos viejo
    class LibroHolder(v: View): RecyclerView.ViewHolder(v)  {
        val  binding=ListaLibrosBinding.bind(v)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LibroHolder {
        context=parent.context
        val layoutInflater= LayoutInflater.from(parent.context)
        val v = layoutInflater.inflate(R.layout.lista_libros, parent, false)
        return LibroHolder(v)
    }

    override fun onBindViewHolder(holder: LibroHolder, position: Int) {
        val elemento = lista[position]
        holder.binding.autor.text=elemento.autor
        holder.binding.titulo.text=elemento.titulo

        holder.binding.cardView.setOnClickListener {
            val i = Intent(context,AddActivity::class.java).apply {
                putExtra("TITULO",elemento.titulo)
                putExtra("AUTOR", elemento.autor)
                putExtra("ID",elemento.ID)
            }
            context.startActivity(i)
        }

    }

    override fun getItemCount(): Int {
        return lista.count()
    }

    //para eliminar al deslizar
    fun removeAt(position: Int){
        lista.drop(position)
        notifyItemRemoved(position)
    }

    fun setData(dato: List<LibrosDataClass>){
        this.lista=dato
        notifyDataSetChanged()
    }

}
