package com.example.roomproject.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.example.roomproject.R
import com.example.roomproject.databinding.ActivityAddBinding
import com.example.roomproject.model.LibrosDataClass
import com.example.roomproject.viewModel.MainViewModel

class AddActivity : AppCompatActivity() {
    lateinit var binding: ActivityAddBinding
    private lateinit var viewModel: MainViewModel
    var autor = ""
    var titulo = ""
    var id=0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)
        cogerDato()
        setUp()

    }

    private fun cogerDato() {
        val bundle = intent.extras
        autor = bundle?.getString("AUTOR").toString()
        titulo = bundle?.getString("TITULO").toString()
        //id = bundle?.getInt("ID")!!
        binding.etAutor.setText(autor)
        binding.etTitulo.setText(titulo)
    }

    private fun setUp() {
        binding.btnGuardar.setOnClickListener {
            guardar()
        }
        binding.btnUpdate.setOnClickListener {
            updateLibro()
        }
        binding.btnVolver.setOnClickListener {
            onBackPressed()
        }
    }


    private fun updateLibro() {

        autor = binding.etAutor.text.toString()
        titulo = binding.etTitulo.text.toString()


        if (!autor.isEmpty() && !titulo.isEmpty()) {
            val libro = LibrosDataClass(0, titulo, autor)
            viewModel.updateUser(libro)

            Toast.makeText(this, "Apdate", Toast.LENGTH_SHORT).show()
            onBackPressed()
        } else {
            Toast.makeText(this, "Apdate", Toast.LENGTH_SHORT).show()
        }

    }

    private fun guardar() {
        autor = binding.etAutor.text.toString()
        titulo = binding.etTitulo.text.toString()

        if (!autor.isEmpty() && !titulo.isEmpty()) {
            val libro = LibrosDataClass(0, titulo, autor)
            viewModel.addUser(libro)
            onBackPressed()

            Toast.makeText(this, "Añadido", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show()
        }
    }
}