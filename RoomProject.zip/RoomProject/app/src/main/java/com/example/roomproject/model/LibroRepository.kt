package com.example.roomproject.model

import androidx.lifecycle.LiveData

class LibroRepository(private val libroDao:DAOLibros) {

    //fun todosLibros():LiveData<List<LibrosDataClass>> = libroDao.getLibros()
    val libro: LiveData<List<LibrosDataClass>> = libroDao.getLibros()




    fun addLibro(libro: LibrosDataClass) {
        libroDao.addLibro(libro)
    }

    fun removeLibro(libro: LibrosDataClass) {
        libroDao.deleteLibro(libro)
    }

    fun updateLibro(libro: LibrosDataClass) {
        libroDao.updateLibro(libro)
    }

    fun borrarTodo() {
        libroDao.deleteAll()
    }

    /*fun constarId(id: Int): LiveData<List<LibrosDataClass>> = libroDao.getId(id)

    fun consultarTitulo(tit: String): LiveData<List<LibrosDataClass>> = libroDao.getTitulo(tit)

    fun consultarAutor(au: String): LiveData<List<LibrosDataClass>> = libroDao.getAutor(au)
 */
}

