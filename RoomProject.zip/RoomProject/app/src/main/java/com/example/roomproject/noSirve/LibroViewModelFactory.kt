package com.example.roomproject.borra

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.roomproject.model.LibroRepository
import java.lang.IllegalArgumentException

/*class LibroViewModelFactory(
    private val repository: LibroRepository
    ):ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if(modelClass.isAssignableFrom(MainViewModel::class.java)){
            return MainViewModel(repository) as T
    }
        throw IllegalArgumentException("Unknown View Model class")
    }
}*/