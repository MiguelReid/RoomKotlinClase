package com.example.roomproject.borra

import android.content.Intent
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.example.roomproject.databinding.ListaLibrosBinding
import com.example.roomproject.model.LibrosDataClass
import com.example.roomproject.view.AddActivity

/*class ViewHolder(v:View) : RecyclerView.ViewHolder(v){
    private val binding = ListaLibrosBinding.bind(v)

    fun render(libro:LibrosDataClass){
        binding.titulo.text = libro.titulo
        binding.autor.text = libro.autor
        val i = Intent(this,AddActivity::class.java).apply {
            putExtra("NOMBRE",elemento.nombre)
            putExtra("EMAIL",elemento.email)
            putExtra("ID",elemento.id)
        }
        context.startActivity(i)
    }
}*/