package com.example.roomproject.model

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [LibrosDataClass::class], version = 1, exportSchema = false)
abstract class LibrosDataBase : RoomDatabase(){
    abstract val libroDao: DAOLibros

    companion object{
        @Volatile
        private var INSTANCE: LibrosDataBase?=null
        fun getInstance(c: Context): LibrosDataBase{
            var ins = INSTANCE
            if (ins != null) {
                return ins
            }
            synchronized(this) {
                var instance  = Room.databaseBuilder(
                        c.applicationContext,
                        LibrosDataBase::class.java,
                        "Libros_data_database"
                    ).build()
                INSTANCE = instance
                return instance
                }

            }
        }

}