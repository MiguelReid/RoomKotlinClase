package com.example.roomproject.viewModel

import android.app.Application
import android.util.Patterns
import androidx.lifecycle.*
import com.example.roomproject.model.LibroRepository
import com.example.roomproject.model.LibrosDataBase
import com.example.roomproject.model.LibrosDataClass
import kotlinx.coroutines.Dispatchers

import kotlinx.coroutines.launch

class MainViewModel(application: Application): AndroidViewModel(application) {

    val readAllData: LiveData<List<LibrosDataClass>>
    private val repository: LibroRepository

    init {
        val userDao = LibrosDataBase.getInstance(
            application
        ).libroDao
        repository = LibroRepository(userDao)
        readAllData = repository.libro
    }

    fun addUser(li: LibrosDataClass){
        viewModelScope.launch(Dispatchers.IO) {
            repository.addLibro(li)
        }
    }

    fun updateUser(li: LibrosDataClass){
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateLibro(li)
        }
    }

    fun deleteUser(li: LibrosDataClass){
        viewModelScope.launch(Dispatchers.IO) {
            repository.removeLibro(li)
        }
    }

    fun deleteAllUsers(){
        viewModelScope.launch(Dispatchers.IO) {
            repository.borrarTodo()
        }
    }


}